import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/player.dart';
import '../services/position_fit_service.dart';
import '../widgets/ability_radar_chart.dart';
import '../widgets/pin_badge.dart';
import '../widgets/player_issue_section.dart';

class PlayerDetailScreen extends StatelessWidget {
  const PlayerDetailScreen({
    super.key,
    required this.player,
  });

  final Player player;

  static const Color _accentRed = Color(0xFFC0392B);
  static const Color _boardColor = Color(0xFFE9E8E3);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: _boardColor,
        appBar: AppBar(
          title: Text(player.name),
          backgroundColor: const Color(0xFFF7F5EF),
          foregroundColor: const Color(0xFF252525),
          elevation: 1,
          actions: [
            IconButton(
              tooltip: '編集',
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => Navigator.pop(context, 'edit'),
            ),
            IconButton(
              tooltip: '削除',
              icon: const Icon(Icons.delete_outline),
              color: _accentRed,
              onPressed: () => Navigator.pop(context, 'delete'),
            ),
          ],
          bottom: const TabBar(
            labelColor: _accentRed,
            unselectedLabelColor: Color(0xFF666666),
            indicatorColor: _accentRed,
            tabs: [
              Tab(
                icon: Icon(Icons.badge_outlined),
                text: 'スカウトカード',
              ),
              Tab(
                icon: Icon(Icons.flag_outlined),
                text: '改善点',
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _ScoutingBoard(player: player),
            PlayerIssueSection(player: player),
          ],
        ),
      ),
    );
  }
}

class _ScoutingBoard extends StatelessWidget {
  const _ScoutingBoard({
    required this.player,
  });

  final Player player;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isDesktop = constraints.maxWidth >= 1100;
        final isTablet = constraints.maxWidth >= 700;

        return Container(
          decoration: const BoxDecoration(
            color: Color(0xFFE9E8E3),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFFF1F0EC),
                Color(0xFFE1E0DC),
              ],
            ),
          ),
          child: Stack(
            children: [
              const Positioned(
                top: 10,
                left: 10,
                child: _BoardScrew(),
              ),
              const Positioned(
                top: 10,
                right: 10,
                child: _BoardScrew(),
              ),
              const Positioned(
                bottom: 10,
                left: 10,
                child: _BoardScrew(),
              ),
              const Positioned(
                bottom: 10,
                right: 10,
                child: _BoardScrew(),
              ),
              SingleChildScrollView(
                padding: EdgeInsets.symmetric(
                  horizontal: isDesktop ? 34 : 16,
                  vertical: 28,
                ),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 1500),
                    child: isDesktop
                        ? _DesktopLayout(player: player)
                        : _CompactLayout(
                            player: player,
                            isTablet: isTablet,
                          ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _DesktopLayout extends StatelessWidget {
  const _DesktopLayout({
    required this.player,
  });

  final Player player;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 280,
          child: Column(
            children: [
              _NumberCard(player: player),
              const SizedBox(height: 26),
              _PhysicalDataCard(player: player),
            ],
          ),
        ),
        const SizedBox(width: 26),
        Expanded(
          flex: 5,
          child: Column(
            children: [
              _PlayerInformationCard(player: player),
              const SizedBox(height: 28),
              _PositionSuitabilitySection(player: player),
            ],
          ),
        ),
        const SizedBox(width: 26),
        SizedBox(
          width: 385,
          child: Column(
            children: [
              _AbilityCard(player: player),
              const SizedBox(height: 28),
              const _IssueMemoCard(),
            ],
          ),
        ),
      ],
    );
  }
}

class _CompactLayout extends StatelessWidget {
  const _CompactLayout({
    required this.player,
    required this.isTablet,
  });

  final Player player;
  final bool isTablet;

  @override
  Widget build(BuildContext context) {
    if (!isTablet) {
      return Column(
        children: [
          _NumberCard(player: player),
          const SizedBox(height: 24),
          _PlayerInformationCard(player: player),
          const SizedBox(height: 24),
          _PhysicalDataCard(player: player),
          const SizedBox(height: 24),
          _AbilityCard(player: player),
          const SizedBox(height: 24),
          _PositionSuitabilitySection(player: player),
          const SizedBox(height: 24),
          const _IssueMemoCard(),
        ],
      );
    }

    return Column(
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 260,
              child: Column(
                children: [
                  _NumberCard(player: player),
                  const SizedBox(height: 24),
                  _PhysicalDataCard(player: player),
                ],
              ),
            ),
            const SizedBox(width: 24),
            Expanded(
              child: _PlayerInformationCard(player: player),
            ),
          ],
        ),
        const SizedBox(height: 24),
        _AbilityCard(player: player),
        const SizedBox(height: 24),
        _PositionSuitabilitySection(player: player),
        const SizedBox(height: 24),
        const _IssueMemoCard(),
      ],
    );
  }
}

class _NumberCard extends StatelessWidget {
  const _NumberCard({
    required this.player,
  });

  final Player player;

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: -0.012,
      child: _PaperCard(
        paperColor: const Color(0xFFE8D4AA),
        pinColor: const Color(0xFFC0392B),
        padding: const EdgeInsets.fromLTRB(24, 34, 24, 30),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 8,
              ),
              decoration: BoxDecoration(
                border: Border.all(
                  color: const Color(0xFFC0392B),
                  width: 2,
                ),
              ),
              child: const Text(
                'PLAYER CARD',
                style: TextStyle(
                  color: Color(0xFF9E2E24),
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2.2,
                ),
              ),
            ),
            const SizedBox(height: 18),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                player.number.toString(),
                style: const TextStyle(
                  color: Color(0xFFC0392B),
                  fontSize: 150,
                  height: 0.95,
                  fontWeight: FontWeight.w900,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 8,
              ),
              color: const Color(0xFFC0392B),
              child: Text(
                player.position.toUpperCase(),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.3,
                ),
              ),
            ),
            const SizedBox(height: 22),
            Text(
              player.name,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF242424),
                fontSize: 27,
                fontWeight: FontWeight.w600,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PhysicalDataCard extends StatelessWidget {
  const _PhysicalDataCard({
    required this.player,
  });

  final Player player;

  String _formatNumber(double value) {
    if (value == value.roundToDouble()) {
      return value.toStringAsFixed(0);
    }

    return value.toStringAsFixed(1);
  }

  @override
  Widget build(BuildContext context) {
    final values = [
      _LabelValue(
        label: '身長',
        value: '${_formatNumber(player.height)} cm',
      ),
      _LabelValue(
        label: '体重',
        value: '${_formatNumber(player.weight)} kg',
      ),
      _LabelValue(
        label: '指高（立位）',
        value: '${_formatNumber(player.standingReach)} cm',
      ),
      _LabelValue(
        label: '最高到達点',
        value: '${_formatNumber(player.maxReach)} cm',
      ),
      _LabelValue(
        label: 'ブロック到達点',
        value: '${_formatNumber(player.blockReach)} cm',
      ),
      _LabelValue(
        label: 'ジャンプ高',
        value: '${_formatNumber(player.jumpHeight)} cm',
      ),
      _LabelValue(
        label: '利き手',
        value: player.dominantHand,
      ),
      _LabelValue(
        label: '学年',
        value: player.grade,
      ),
    ];

    return Transform.rotate(
      angle: 0.007,
      child: _PaperCard(
        pinColor: const Color(0xFF315D91),
        tapeTopRight: true,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const _SectionHeading(title: 'PHYSICAL DATA'),
            const SizedBox(height: 8),
            for (final item in values)
              _UnderlinedDataRow(
                label: item.label,
                value: item.value,
              ),
          ],
        ),
      ),
    );
  }
}

class _PlayerInformationCard extends StatelessWidget {
  const _PlayerInformationCard({
    required this.player,
  });

  final Player player;

  List<String> _createStrengths() {
    final strengths = <String>[];

    if (player.block >= 7) {
      strengths.add('高いブロック力');
    }

    if (player.spike >= 7) {
      strengths.add('スパイクの決定力');
    }

    if (player.serve >= 7) {
      strengths.add('強力なサーブ');
    }

    if (player.reception >= 7) {
      strengths.add('安定したレセプション');
    }

    if (player.dig >= 7) {
      strengths.add('高いディグ能力');
    }

    if (player.toss >= 7) {
      strengths.add('正確なトス');
    }

    if (player.mobility >= 7) {
      strengths.add('高い機動力');
    }

    if (player.maxReach >= 300) {
      strengths.add('高い最高到達点');
    }

    if (strengths.isEmpty) {
      strengths.add('能力値を編集中');
    }

    return strengths.take(5).toList();
  }

  @override
  Widget build(BuildContext context) {
    final information = [
      _LabelValue(label: '氏名', value: player.name),
      _LabelValue(label: '背番号', value: player.number.toString()),
      _LabelValue(label: 'ポジション', value: player.position),
      _LabelValue(label: '学年', value: player.grade),
      _LabelValue(label: '利き手', value: player.dominantHand),
      _LabelValue(
        label: 'ジャンプ高',
        value: '${player.jumpHeight.toStringAsFixed(1)} cm',
      ),
    ];

    final strengths = _createStrengths();

    return Transform.rotate(
      angle: 0.003,
      child: _PaperCard(
        pinColor: const Color(0xFFC0392B),
        padding: const EdgeInsets.fromLTRB(32, 34, 32, 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const _SectionHeading(title: 'PLAYER INFORMATION'),
            const SizedBox(height: 18),
            LayoutBuilder(
              builder: (context, constraints) {
                final useTwoColumns = constraints.maxWidth >= 500;

                return GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: information.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: useTwoColumns ? 2 : 1,
                    mainAxisExtent: 90,
                    mainAxisSpacing: 14,
                    crossAxisSpacing: 30,
                  ),
                  itemBuilder: (context, index) {
                    final item = information[index];

                    return _InformationField(
                      label: item.label,
                      value: item.value,
                    );
                  },
                );
              },
            ),
            const SizedBox(height: 28),
            const Text(
              'KEY STRENGTHS',
              style: TextStyle(
                color: Color(0xFF272727),
                fontSize: 14,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                for (int index = 0; index < strengths.length; index++)
                  Transform.rotate(
                    angle: index.isEven ? -0.008 : 0.008,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 9,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFFCF6),
                        border: Border.all(
                          color: const Color(0xFFC95A50),
                        ),
                      ),
                      child: Text(
                        strengths[index],
                        style: const TextStyle(
                          color: Color(0xFFB1392E),
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _AbilityCard extends StatelessWidget {
  const _AbilityCard({
    required this.player,
  });

  final Player player;

  @override
  Widget build(BuildContext context) {
    final values = <String, int>{
      'スパイク': player.spike,
      'サーブ': player.serve,
      'レセプ': player.reception,
      'ディグ': player.dig,
      'トス': player.toss,
      'ブロック': player.block,
      '機動力': player.mobility,
    };

    return Transform.rotate(
      angle: 0.009,
      child: _PaperCard(
        pinColor: const Color(0xFF315D91),
        tapeTopLeft: true,
        tapeTopRight: true,
        padding: const EdgeInsets.fromLTRB(22, 34, 22, 26),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const _SectionHeading(title: 'ABILITY RADAR'),
            const SizedBox(height: 8),
            AbilityRadarChart(values: values),
            const SizedBox(height: 14),
            const Divider(
              color: Color(0xFFD0CBC0),
              height: 1,
            ),
            const SizedBox(height: 16),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: values.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisExtent: 38,
                crossAxisSpacing: 16,
              ),
              itemBuilder: (context, index) {
                final entry = values.entries.elementAt(index);

                return Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        color: Color(0xFFC0392B),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        entry.key,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Text(
                      (entry.value * 10).toString(),
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _PositionSuitabilitySection extends StatelessWidget {
  const _PositionSuitabilitySection({
    required this.player,
  });

  final Player player;

  static const Map<String, Color> _colors = {
    'WS': Color(0xFFC0392B),
    'MB': Color(0xFF315D91),
    'OP': Color(0xFF74502F),
    'S': Color(0xFF356B46),
  };

  static const Map<String, String> _displayNames = {
    'WS': 'WS',
    'MB': 'MB',
    'OP': 'OP',
    'S': 'SET',
  };

  static const Map<String, String> _comments = {
    'WS': 'スパイク・レセプション・守備力を生かせるポジション',
    'MB': 'ブロック力と機動力を生かして中央を守れるポジション',
    'OP': '攻撃力とブロック力を中心に得点を狙えるポジション',
    'S': 'トス精度と機動力を使ってゲームを組み立てるポジション',
  };

  @override
  Widget build(BuildContext context) {
    final allScores = PositionFitService.calculate(player);

    final scores = <String, double>{
      for (final key in ['WS', 'MB', 'OP', 'S'])
        if (allScores.containsKey(key)) key: allScores[key]!,
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 8),
          child: Text(
            'POSITION SUITABILITY',
            style: TextStyle(
              color: Color(0xFF252525),
              fontSize: 15,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
        ),
        const SizedBox(height: 18),
        LayoutBuilder(
          builder: (context, constraints) {
            final columns = constraints.maxWidth >= 720 ? 4 : 2;
            final cardWidth =
                (constraints.maxWidth - ((columns - 1) * 14)) / columns;

            return Wrap(
              spacing: 14,
              runSpacing: 18,
              children: [
                for (int index = 0; index < scores.length; index++)
                  SizedBox(
                    width: cardWidth,
                    child: _PositionCard(
                      code: scores.keys.elementAt(index),
                      displayName:
                          _displayNames[scores.keys.elementAt(index)] ??
                              scores.keys.elementAt(index),
                      score: scores.values.elementAt(index),
                      color: _colors[scores.keys.elementAt(index)] ??
                          const Color(0xFF555555),
                      comment: _comments[scores.keys.elementAt(index)] ?? '',
                      angle: index.isEven ? -0.008 : 0.008,
                    ),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _PositionCard extends StatelessWidget {
  const _PositionCard({
    required this.code,
    required this.displayName,
    required this.score,
    required this.color,
    required this.comment,
    required this.angle,
  });

  final String code;
  final String displayName;
  final double score;
  final Color color;
  final String comment;
  final double angle;

  @override
  Widget build(BuildContext context) {
    final percentage = (score * 10).clamp(0, 100).round();

    return Transform.rotate(
      angle: angle,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.topCenter,
        children: [
          Container(
            constraints: const BoxConstraints(minHeight: 265),
            padding: const EdgeInsets.fromLTRB(18, 34, 18, 20),
            decoration: BoxDecoration(
              color: const Color(0xFFF8F5ED),
              border: Border.all(
                color: const Color(0xFFD6D0C3),
              ),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x35000000),
                  blurRadius: 12,
                  offset: Offset(0, 7),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  displayName,
                  style: TextStyle(
                    color: color,
                    fontSize: 27,
                    fontWeight: FontWeight.w900,
                    fontStyle: FontStyle.italic,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  '$percentage%',
                  style: TextStyle(
                    color: color,
                    fontSize: 43,
                    height: 1,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 17),
                ClipRRect(
                  borderRadius: BorderRadius.circular(3),
                  child: LinearProgressIndicator(
                    value: percentage / 100,
                    minHeight: 8,
                    backgroundColor: const Color(0xFFDDD4C3),
                    valueColor: AlwaysStoppedAnimation<Color>(color),
                  ),
                ),
                const SizedBox(height: 18),
                Text(
                  comment,
                  style: const TextStyle(
                    color: Color(0xFF333333),
                    fontSize: 14,
                    height: 1.65,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            top: -10,
            child: PinBadge(
              size: 21,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _IssueMemoCard extends StatelessWidget {
  const _IssueMemoCard();

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: -0.01,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.topCenter,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(28, 34, 28, 28),
            decoration: const BoxDecoration(
              color: Color(0xFFE8D06F),
              boxShadow: [
                BoxShadow(
                  color: Color(0x38000000),
                  blurRadius: 14,
                  offset: Offset(0, 8),
                ),
              ],
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'PLAYER ISSUES',
                  style: TextStyle(
                    color: Color(0xFF9F3026),
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
                SizedBox(height: 12),
                Divider(
                  color: Color(0x55724822),
                ),
                SizedBox(height: 12),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.arrow_upward,
                      size: 20,
                      color: Color(0xFF5A451B),
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        '登録済みの改善点は、画面上部の「改善点」タブから確認・追加できます。',
                        style: TextStyle(
                          color: Color(0xFF3D321B),
                          fontSize: 16,
                          height: 1.8,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const Positioned(
            top: -10,
            child: PinBadge(
              size: 21,
              color: Color(0xFFC0392B),
            ),
          ),
        ],
      ),
    );
  }
}

class _PaperCard extends StatelessWidget {
  const _PaperCard({
    required this.child,
    this.paperColor = const Color(0xFFF8F5ED),
    this.pinColor = const Color(0xFFC0392B),
    this.padding = const EdgeInsets.fromLTRB(24, 34, 24, 24),
    this.tapeTopLeft = false,
    this.tapeTopRight = false,
  });

  final Widget child;
  final Color paperColor;
  final Color pinColor;
  final EdgeInsets padding;
  final bool tapeTopLeft;
  final bool tapeTopRight;

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          width: double.infinity,
          padding: padding,
          decoration: BoxDecoration(
            color: paperColor,
            border: Border.all(
              color: const Color(0xFFD8D2C6),
            ),
            boxShadow: const [
              BoxShadow(
                color: Color(0x36000000),
                blurRadius: 16,
                offset: Offset(0, 8),
              ),
              BoxShadow(
                color: Color(0x16000000),
                blurRadius: 3,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: child,
        ),
        Positioned(
          top: -10,
          left: 0,
          right: 0,
          child: Center(
            child: PinBadge(
              size: 22,
              color: pinColor,
            ),
          ),
        ),
        if (tapeTopLeft)
          const Positioned(
            top: -8,
            left: -10,
            child: _MaskingTape(angle: -0.55),
          ),
        if (tapeTopRight)
          const Positioned(
            top: -8,
            right: -10,
            child: _MaskingTape(angle: 0.55),
          ),
      ],
    );
  }
}

class _SectionHeading extends StatelessWidget {
  const _SectionHeading({
    required this.title,
  });

  final String title;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: Color(0xFF242424),
            fontSize: 15,
            fontWeight: FontWeight.bold,
            letterSpacing: 2.2,
          ),
        ),
        const SizedBox(height: 10),
        Stack(
          children: [
            Container(
              height: 1,
              color: const Color(0xFFD0CBC0),
            ),
            Container(
              width: 82,
              height: 2,
              color: const Color(0xFFC0392B),
            ),
          ],
        ),
      ],
    );
  }
}

class _InformationField extends StatelessWidget {
  const _InformationField({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(bottom: 9),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFD3CDC0),
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 9,
              vertical: 4,
            ),
            color: const Color(0xFFE9DFC5),
            child: Text(
              label,
              style: const TextStyle(
                color: Color(0xFF5F5A50),
                fontSize: 11,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.2,
              ),
            ),
          ),
          const SizedBox(height: 7),
          Text(
            value,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Color(0xFF252525),
              fontSize: 22,
              fontWeight: FontWeight.w600,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }
}

class _UnderlinedDataRow extends StatelessWidget {
  const _UnderlinedDataRow({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 2,
        vertical: 11,
      ),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Color(0xFFD2CCC0),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: Color(0xFF333333),
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Text(
            value,
            style: const TextStyle(
              color: Color(0xFF242424),
              fontSize: 19,
              fontWeight: FontWeight.w700,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }
}

class _MaskingTape extends StatelessWidget {
  const _MaskingTape({
    required this.angle,
  });

  final double angle;

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: angle,
      child: Container(
        width: 74,
        height: 22,
        decoration: BoxDecoration(
          color: const Color(0xB8E4D095),
          border: Border.all(
            color: const Color(0x33A58B4A),
          ),
        ),
      ),
    );
  }
}

class _BoardScrew extends StatelessWidget {
  const _BoardScrew();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 13,
      height: 13,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const RadialGradient(
          center: Alignment(-0.3, -0.3),
          colors: [
            Color(0xFFF2F2F2),
            Color(0xFF9B9B99),
            Color(0xFF555553),
          ],
        ),
        border: Border.all(
          color: const Color(0xFF6C6C69),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x66000000),
            blurRadius: 3,
            offset: Offset(0, 1),
          ),
        ],
      ),
      child: Transform.rotate(
        angle: math.pi / 4,
        child: Center(
          child: Container(
            width: 7,
            height: 1,
            color: const Color(0xFF555555),
          ),
        ),
      ),
    );
  }
}

class _LabelValue {
  const _LabelValue({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;
}